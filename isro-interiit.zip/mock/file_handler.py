def handle_file(name):
    return [
        True,
        None
    ]